1- to run this app please install the following package using the instructions:
 - express: npm i express
 - mongoose: npm i mongoose
 - angular and angular-route: npm i angular angular-route

2 - Got to your browser with Chrome and type the following URL:
http://localhost:3001/

3- Functionnalities:
  - list cities: /cities
  - city details: /city/:cityId
  - delete a city: /city/:cityId and click the delete button
  - add a city: /city and fill in the required fields